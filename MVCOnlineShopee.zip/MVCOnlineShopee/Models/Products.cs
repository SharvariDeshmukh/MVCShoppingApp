﻿using System;
using System.Collections.Generic;

namespace MVCOnlineShopee.Models
{
    public partial class Products
    {
        public string Pid { get; set; }
        public string Pname { get; set; }
        public string Description { get; set; }
        public int? Price { get; set; }
        public string Pimage { get; set; }
    }
}
