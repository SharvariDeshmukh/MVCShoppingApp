﻿using System;
using System.Collections.Generic;

namespace MVCOnlineShopee.Models
{
    public partial class Students
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int? TotalMarks { get; set; }
    }
}
