﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MVCOnlineShopee.Models
{
    public partial class ShoppingAppContext : DbContext
    {
        public ShoppingAppContext()
        {
        }

        public ShoppingAppContext(DbContextOptions<ShoppingAppContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Products> Products { get; set; }
        public virtual DbSet<Register> Register { get; set; }
        public virtual DbSet<Students> Students { get; set; }
        public virtual DbSet<Userorders> Userorders { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=MUM02L9601\\SQLEXPRESS;Database=ShoppingApp;User ID=sa;Password=Password123");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Products>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__products__DD37D91A683E8499");

                entity.ToTable("products");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasColumnName("description")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pimage)
                    .HasColumnName("pimage")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Price).HasColumnName("price");
            });

            modelBuilder.Entity<Register>(entity =>
            {
                entity.HasKey(e => e.Uname)
                    .HasName("PK__Register__C7D2484F11307C65");

                entity.Property(e => e.Uname)
                    .HasColumnName("uname")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Address)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Dob)
                    .HasColumnName("dob")
                    .HasColumnType("date");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Gender).HasColumnName("gender");

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Students>(entity =>
            {
                entity.HasKey(e => e.StudentId)
                    .HasName("PK__students__4D11D63C14F65B5C");

                entity.ToTable("students");

                entity.Property(e => e.StudentId)
                    .HasColumnName("studentId")
                    .ValueGeneratedNever();

                entity.Property(e => e.StudentName)
                    .HasColumnName("studentName")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.TotalMarks).HasColumnName("totalMarks");
            });

            modelBuilder.Entity<Userorders>(entity =>
            {
                entity.HasKey(e => e.Tranid)
                    .HasName("PK__userorde__9A599E03E9DBDD15");

                entity.ToTable("userorders");

                entity.Property(e => e.Tranid).HasColumnName("tranid");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Qty).HasColumnName("qty");

                entity.Property(e => e.Transdate)
                    .HasColumnName("transdate")
                    .HasColumnType("date");

                entity.Property(e => e.Username)
                    .HasColumnName("username")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
