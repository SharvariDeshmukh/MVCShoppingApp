﻿using System;
using System.Collections.Generic;

namespace MVCOnlineShopee.Models
{
    public partial class Userorders
    {
        public int Tranid { get; set; }
        public string Username { get; set; }
        public string Pid { get; set; }
        public DateTime? Transdate { get; set; }
        public int? Qty { get; set; }
    }
}
