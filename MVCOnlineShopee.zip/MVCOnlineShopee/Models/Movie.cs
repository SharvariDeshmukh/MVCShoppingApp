﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCOnlineShopee.Models
{
    public class Movie
    {
        //MovieName
        //    Actor
        //    Actress
        //    Director
        //    Year of Release
        public string imageSrc { get; set; }
        public string MovieName { get; set; }
        public string Actor { get; set; }
        public string Actress { get; set; }
        public string Director { get; set; }
        public int YearOfRelease { get; set; }
    }
}
