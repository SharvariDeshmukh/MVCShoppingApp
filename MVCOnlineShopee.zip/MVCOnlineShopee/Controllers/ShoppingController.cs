﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCOnlineShopee.Models;
namespace MVCOnlineShopee.Controllers
{
    public class ShoppingController : Controller
    {
        ShoppingAppContext dc = new ShoppingAppContext();
        public IActionResult Index()
        {
            var res = from t in dc.Products select t;
            return View(res);
        }
       
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(Register p)
        {
            dc.Register.Add(p);// 7 record this will update the list(front end)

            int rowsaffect = dc.SaveChanges();// update tp database

            if (rowsaffect > 0)
            {
                ViewData["a"] = "You registered Successfully";
            }
            else
            {
                ViewData["a"] = "Error Occured";
            }

            return View();
        }

        public IActionResult login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult login(string uname, string pwd)
        {
            var res = from t in dc.Register 
                      where t.Uname==uname && t.Password==pwd select t;
            var logged = dc.Register.Where(j => j.Uname.Equals(uname) && j.Password.Equals(pwd)).Count();
            if (logged>0)
            {
                ViewData["a"] = "Login Successful";
            }
            else
            {
                ViewData["a"] = "Login failed";
            }
            return View();
        }

        public IActionResult Buy(string Pid)
        {
            Products st = dc.Products.Find(Pid);
            ViewBag.a = "searched";
            return View(st);
        }
    }
}
