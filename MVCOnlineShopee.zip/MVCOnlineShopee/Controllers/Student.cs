﻿using Microsoft.AspNetCore.Mvc;
using MVCOnlineShopee.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//THIS IS THE CONTROLLER
namespace MVCOnlineShopee.Controllers
{
  
    public class Student : Controller
    {
        ShoppingAppContext dc = new ShoppingAppContext();
        public IActionResult Index()
        {
            var res = from t in dc.Students select t;

            return View(res);
        }


        public IActionResult AddStudent()
        {

            return View();

        }

        // 3 ways to read the value of textbox

        [HttpPost]
        public IActionResult AddStudent(Students ob)
        {

            dc.Students.Add(ob);// 7 record this will update the list(front end)

            int rowsaffect = dc.SaveChanges();// update tp database

            if (rowsaffect > 0)
            {
                ViewData["a"] = "New Students Add Successfully";
            }
            else
            {
                ViewData["a"] = "Error Occured";
            }

            return View();

        }

        public IActionResult DeleteStudent()
        {
            return View();
        }


        [HttpPost]
        public IActionResult DeleteStudent(int id)
        {

            var res = dc.Students.Find(id);

            dc.Students.Remove(res);


            int rowsaffect = dc.SaveChanges();// update tp database

            if (rowsaffect > 0)
            {
                ViewData["a"] = "Record Deleted Successfully";
            }
            else
            {
                ViewData["a"] = "Error Occured";
            }

            return View();
        }

        public IActionResult UpdateStudent()
        {
            return View();

        }

        [HttpPost]
        public IActionResult UpdateStudent(int id, string NewName)
        {

            var res = dc.Students.Find(id);

            res.StudentName = NewName;

            dc.Students.Update(res);


            int rowsaffect = dc.SaveChanges();// update tp database

            if (rowsaffect > 0)
            {
                ViewData["a"] = "Record Updated Successfully";
            }
            else
            {
                ViewData["a"] = "Error Occured";
            }

            return View();

        }

        public IActionResult SearchStudent()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SearchStudent(int id)
        {
            Students st = dc.Students.Find(id);
            ViewBag.a = "searched";
            return View(st);
        }
    }


}

