﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVCOnlineShopee.Models;
namespace MVCOnlineShopee.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View();
        }
        public ViewResult About()
        {
            return View();
        }

        public IActionResult FindGreatest()
        {
            return View();
        }

        [HttpPost]
        public IActionResult FindGreatest(string num1, string num2)
        {
            int num11 = Int32.Parse(num1);
            int num22 = Int32.Parse(num2);
            int num;
            if (num11 > num22)
            {
                num = num11;
            }
            else
            {
                num = num22;
            }

            ViewBag.gnum = num;
            return View();
        }
        [HttpPost]
        public IActionResult AcceptNPrint(string num, string name)
        {
            int number = Int32.Parse(num);
            ViewBag.n = number;
            ViewBag.uname = name;
            return View();
        }


        public IActionResult AcceptNPrint()
        {
            return View();
        }
        public ViewResult Contact()
        {
            string[] countries = { "india", "usa", "uk", "canada" };
            int[] num = { 10, 20, 30, 40, 50 };

            ViewBag.c = countries;
            ViewBag.num = num;

            ViewData["numbers"] = num;
            ViewData["countries"] = countries;
            return View();
        }

        public IActionResult Login()
        {
            return View();

        }
        [HttpPost]
        public IActionResult Login(string uname, string pwd)
        {
            if (uname == "admin" && pwd == "india123") {
                ViewBag.op = "Valid user";
            }
            else
            {
                ViewBag.op = "Invalid user";
            }
            return View();
        }

        public IActionResult register()
        {
            return View();
        }


//        empid -> Textbox
//empname -> Textbox
//dob -> date(calander)
//gender -> Radio
//nationality -> Dropdown
        [HttpPost]
        public IActionResult register(string empid, string empname, DateTime dob, string gen, string nationality)
        {
            ViewBag.empid = empid;
            ViewBag.empname = empname;
            ViewBag.dob = dob;
            ViewBag.gen = gen;
            ViewBag.nationality = nationality;

            return View();
        }

         public IActionResult viewResult(string name, string age) 
        {
            ViewBag.name = name;
            ViewBag.age = age;
            return View();
        }

        public IActionResult images()
        {
            string[] st = { "/images/pic1.jpg ", "/images/pic2.jpg " , "/images/pic3.jpg " };
            ViewBag.st = st;
            return View();
        }

        List<Movie> list = new List<Movie>()
        {

            new Movie(){ imageSrc="/images/pic1.jpg" ,YearOfRelease=2010, MovieName="Books 3", Actor="X YX", Actress="FEE", Director= "LL"},
            new Movie(){ imageSrc="/images/pic2.jpg",YearOfRelease=2000, MovieName="ABCC", Actor="X GG", Actress="GGD SSAS", Director= "TT RR"},
            new Movie(){imageSrc="/images/pic3.jpg" ,YearOfRelease=2004, MovieName="CIIIF", Actor="L MNO", Actress="SDSD DSS", Director="GGG"},
            new Movie(){ imageSrc="/images/pic4.jpg",YearOfRelease=2016, MovieName="LMNOP", Actor="abc", Actress="FF DD ss", Director= "GGG HHH"}


        };
        public IActionResult MoviesDisplay()
        {

            return View(list);
        }
     
        //public IActionResult ViewProducts()
        //{
        //    return View(Plist);
        //}


    }
}
